IBIZA VIP MOVE — FINAL WEBSITE V6

This package keeps the V5 visual direction and typography the user approved.

Final refinements:
- Same thin, modern system typography from V5.
- All brochure-derived service images remain local, so the preview works without external image hosting.
- Added Professional Partnerships section.
- Added Discretion & Confidentiality section.
- Improved Contact & VIP Requests ending.
- Better desktop/mobile hover and responsive behavior.
- Added canonical, robots, Open Graph and LocalBusiness structured data.
- Kept WhatsApp +34 613 75 62 11 and partnership@ibizavipmove.com from the approved V5 website version.

Important before publishing:
- Confirm final contact details.
- Replace any brochure-derived image with original licensed source photography if needed for final public use.
- Upload index.html and the complete assets/ folder together.
